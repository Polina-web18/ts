# news-JS

Run application:  
- Copy and rename `.env.example` to `.env` and set variables with your data  
- Install dependencies by running command `npm install` in your terminal
- Run command in your terminal `npm start`  

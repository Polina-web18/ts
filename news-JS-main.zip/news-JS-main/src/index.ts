import axios from 'axios';

// перечисление статусов новостей
enum NewsStatus {
    NOT_READ = 'Не прочитано',
    READ = 'Прочитано'
}

// Интерфейс для статьи
interface NewsArticle {
    id: number; 
    title: string;
    description: string;
    url: string;
    urlToImage: string;
    publishedAt: string;
    author: string;
    status: NewsStatus; // статус статьи
}

// ответ API
interface NewsResponse {
    articles: NewsArticle[];
}

//  дженерик для общего запроса
async function fetchData<T>(url: string): Promise<T> {
    const response = await axios.get<T>(url);
    return response.data;
}

class NewsAPI {
    private apiUrl: string;
    private apiKey: string;

    constructor() {
        this.apiUrl = process.env.API_URL!;
        this.apiKey = process.env.API_KEY!;
    }

    // получение новостей, функция
    public async fetchNews(): Promise<NewsArticle[]> {
        try {
            const response = await fetchData<NewsResponse>(
                `${this.apiUrl}top-headlines?country=us&apiKey=${this.apiKey}`
            );
            return response.articles.map(article => ({
                ...article,
                id: Date.now() + Math.random(), // Уникальный идентификатор на основе времени и случайного числа
                status: NewsStatus.NOT_READ // Изначально статья не прочитана
            }));
        } catch (error) {
            console.error('Error fetching news:', error);
            return [];
        }
    }

    // отображение новостей
    public async renderNews(): Promise<void> {
        const articles = await this.fetchNews();
        const newsContainer = document.querySelector('.news') as HTMLElement;

        newsContainer.innerHTML = ''; // очистка контейнера 

        articles.forEach(({ id, title, description, url, status }) => {
            const articleElement = document.createElement('div');
            articleElement.className = 'news__item';
            articleElement.innerHTML = `
                <div class="news__description" style="${status === NewsStatus.READ ? 'text-decoration: line-through; color: grey;' : ''}">
                    <h2>${title}</h2>
                    <p>${description}</p>
                    <a href="${url}" target="_blank">Read More</a>
                </div>
            `;
            newsContainer.appendChild(articleElement);
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const newsAPI = new NewsAPI();
    newsAPI.renderNews();
});